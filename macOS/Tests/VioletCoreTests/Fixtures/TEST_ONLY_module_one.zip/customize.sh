#!/system/bin/sh
# TEST ONLY, never execute
